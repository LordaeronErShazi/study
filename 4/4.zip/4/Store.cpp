//���ڴ˴�����Store��ĳ�Ա����ʵ��
#include"Store.h"
Store::Store()
{
	m_Count=0;
	cout<<"Store default constructor called!"<<endl;
}
Store::Store(int n)
{
	m_Count=m_Books.size();
	cout<<"Store constructor with (int n) called!"<<endl;
}
Store::~Store()
{
	cout<<"Store destructor called!"<<endl;
}
Store::Store(const Store& other):m_Count(other.m_Count)
{
	//ʵ�ֶ�������Ŀ���
	cout<<"Store copy constructor called!"<<endl;
}
void Store::in(Book &b)
{
	m_Books.push_back(b);
	m_Count++;
}
void Store::out(string name)
{
	for(int i = 0; i < m_Books.size(); ++i)
	{
		if(m_Books[i].GetName()==name)
			m_Books.erase(m_Books.begin()+i,m_Books.begin()+i);
	}
	m_Count--;
}
Book Store::findbyID(int ID)
{	//����ID����ͼ�� 
	for(int i = 0; i < m_Books.size(); ++i)
	{
		if(m_Books[i].GetID()==ID)
			return m_Books[i];
	}
	Book book;
	return book;
}
Book Store::findbyName(string name)
{	//����name����ͼ�� 
	for(int i = 0; i < m_Books.size(); ++i)
    {
    	if(m_Books[i].GetName()==name)
    		return m_Books[i];
	}
	Book book;
	return book;
}
void Store::printList()
{	//��ӡ����ͼ�����Ϣ 
	for(int i=0;i<=m_Count-1;i++)
	{
		cout<<"ID="<<m_Books[i].GetID()<<"; Name:"<<m_Books[i].GetName()
		<<"; Author:"<<m_Books[i].GetAuthor()<<"; Date:"<<m_Books[i].GetDate()<<";\n";
	}
}
unsigned int Store::GetCount()
{
	return m_Count;
}
