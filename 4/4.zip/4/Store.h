//���ڴ˴�����Store��Ķ���
#ifndef __STORE_H__
#define __STORE_H__
#include<iostream>
#include<vector>
#include"Book.h"
using namespace std;
class  Store
{
private:
	vector<Book> m_Books;
	//vector<Book> m_Books = vector<Book>();
	unsigned int m_Count;
public:
	Store();
	Store(int n);
	virtual ~Store();
	Store(const Store& other);
	void in(Book &b);
	void out(string name);
	Book findbyID(int ID);
	Book findbyName(string name);
	void printList();
	unsigned GetCount(); 
};
#endif //__STORE_H__

