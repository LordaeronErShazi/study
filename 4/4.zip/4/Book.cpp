//���ڴ˴�����Book��ĳ�Ա����ʵ��
#include"Book.h"
Book::Book()
{
	m_ID=0;
}
Book::~Book()
{
}
Book::Book(const Book& other)
{
	this->m_Author=other.m_Author;
	this->m_Date=other.m_Date;
	this->m_ID=other.m_ID;
	this->m_Introduction=other.m_Introduction;
	this->m_Name=other.m_Name;
	this->m_Page=other.m_Page;
}
string Book::GetName()
{
	return m_Name;
}
unsigned int Book::GetID()
{
	return m_ID;
}
unsigned int Book::GetPage()
{
	return m_Page;
}
string Book::GetIntroduction()
{
	return m_Introduction;
}
string Book::GetAuthor()
{
	return m_Author;
}
string Book::GetDate()
{
	return m_Date;
}
void Book::SetID(int i)
{
	m_ID=i;
}
void Book::SetPage(int i)
{
	m_Page=i;
}
void Book::SetName(string s)
{
	m_Name=s;
}
void Book::SetIntroduction(string s)
{
	m_Introduction=s;
}
void Book::SetAuthor(string s)
{
	m_Author=s;
}
void Book::SetDate(string s)
{
	m_Date=s;
}
