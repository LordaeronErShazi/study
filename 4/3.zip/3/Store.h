//���ڴ˴�����Store��Ķ���
#ifndef __STORE_H__
#define __STORE_H__
#include<iostream>
#include"Book.h"
using namespace std;
class  Store
{
private:
	Book *m_pBook;
	unsigned int m_Count;
public:
	Store();
	Store(int n);
	virtual ~Store();
	Store(const Store& other);
	void in(Book &b);
	void out(string name);
	Book findbyID(int ID);
	Book findbyName(string name);
	void printList();
	unsigned GetCount(); 
};
#endif //__STORE_H__

