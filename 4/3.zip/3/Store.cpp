//���ڴ˴�����Store��ĳ�Ա����ʵ��
#include"Store.h"
Store::Store()
{
	m_Count=0;
	m_pBook=NULL;
	cout<<"Store default constructor called!"<<endl;
}
Store::Store(int n)
{
	m_Count=n;
	m_pBook=new Book[n];
	cout<<"Store constructor with (int n) called!"<<endl;
}
Store::~Store()
{
	m_Count=0;
	if(m_pBook!=NULL)//�ж��Ƿ�Ϊ��ָ�� 
		delete[] m_pBook;
	cout<<"Store destructor called!"<<endl;
}
Store::Store(const Store& other)
{
	//ʵ�ֶ�����������
	m_Count=other.m_Count;
	m_pBook=new Book;
	*m_pBook=*(other.m_pBook);
	cout<<"Store copy constructor called!"<<endl;
}
void Store::in(Book &b)
{
	if(m_pBook==NULL)
	{
		m_pBook=new Book[1];
		m_pBook[0]=b;
	}
	else
	{	Book *nBook=new Book[m_Count+1];
		for(int i=0;i<=m_Count-1;i++)
			nBook[i]=m_pBook[i];
		nBook[m_Count]=b;
		delete[] m_pBook;
		m_pBook=nBook;
		//delete nBook;
	}
	m_Count++;
}
void Store::out(string name)
{
	Book *nBook=new Book[m_Count-1];
	for(int i=0,j=0;i<=m_Count-1;i++)
	{
		if(m_pBook[i].GetName()!=name)
			nBook[j++]=m_pBook[i];
	}
	delete[] m_pBook;
	m_pBook=nBook;
	//delete nBook;
	m_Count--;
}
Book Store::findbyID(int ID)
{	//����ID����ͼ�� 
	int i;
	for(i=0;i<=m_Count-1;i++)
	{
		if(m_pBook[i].GetID()==ID)
			return m_pBook[i];
	}
	if(i==m_Count)
	{
		Book book;
		return book;
	}
}
Book Store::findbyName(string name)
{	//����name����ͼ�� 
	int i;
	for(i=0;i<=m_Count-1;i++)
	{
		if(m_pBook[i].GetName()==name)
			return m_pBook[i];
	}
	Book book;
	if(i==m_Count)
	{
		//Book book;
		return book;
	}
}
void Store::printList()
{	//��ӡ����ͼ�����Ϣ 
	cout<<"There are totally "<< m_Count <<" Books:"<<endl;
	for(int i=0;i<=m_Count-1;i++)
	{
		cout<<"ID="<<m_pBook[i].GetID()<<"; Name:"<<m_pBook[i].GetName()
		<<"; Author:"<<m_pBook[i].GetAuthor()<<"; Date:"<<m_pBook[i].GetDate()<<";\n";
	}
}
unsigned int Store::GetCount()
{
	return m_Count;
}
