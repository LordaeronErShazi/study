//���ڴ˴�����Book��Ķ���
#ifndef __BOOK_H__
#define __BOOK_H__
#include<string>
#include<iostream>
using namespace std;
class  Book
{
private:
	unsigned int m_ID, m_Page;
	string m_Name, m_Introduction, m_Author, m_Date;
public:
	Book();
	virtual ~Book();
	Book(const Book& other);
	unsigned int GetID();
	unsigned int GetPage();
	string GetName();
	string GetIntroduction();
	string GetAuthor();
	string GetDate();
	void SetID(int i);
	void SetPage(int i);
	void SetName(string s);
	void SetIntroduction(string s);
	void SetAuthor(string s);
	void SetDate(string s);	
};
#endif //__BOOK_H__
