#include<iostream>
using  namespace  std;
const  int  pi=3.14159;
class Shape
{
private:
	int m_ID;
public:
	int getID(){ return m_ID; }
	void setID(int ID){ m_ID=ID; }
	int getArea(){ return 0; }
	Shape(int ID):m_ID(ID)
	{
		cout<<"Shape constructor called:"<<m_ID<<endl;
	}
	~Shape()
	{
		cout<<"Shape destructor called:"<<m_ID<<endl;
	}
};
class Circle:public Shape
{
private:
	int r;
public:
	int getr(){ return r; }
	void setr(int R){ r=R; }
	int getArea(){ return pi*r*r;}
	Circle(int R,int ID):r(R),Shape(ID)
	{
		cout<<"Circle constructor called:"<<getID()<<endl; 
	}
	~Circle()
	{
		cout<<"Circle destructor called:"<<getID()<<endl;
	}
};
class Rectangle:public Shape
{
private:
	int h,w;
public:
	int geth(){ return h; }
	int getw(){ return w; }
	void seth(int H){ h=H; }
	void setw(int W){ w=W; }
	int getArea(){ return h*w; }
	Rectangle(int H,int W,int ID):h(H),w(W),Shape(ID)
	{
		cout<<"Rectangle constructor called:"<<getID()<<endl;
	}
	~Rectangle()
	{
		cout<<"Rectangle destructor called:"<<getID()<<endl;
	}
};
int  main()
{
        Shape  s(1);//1��ʾID
        Circle  c(4,2);//4��ʾ�뾶��2��ʾID
        Rectangle  r(4,5,3);//4��5��ʾ���Ϳ���3��ʾID
        cout<<"Shape�����"<<s.getArea()<<endl;
        cout<<"Circle�����"<<c.getArea()<<endl;
        cout<<"Rectangle�����"<<r.getArea()<<endl;
}
