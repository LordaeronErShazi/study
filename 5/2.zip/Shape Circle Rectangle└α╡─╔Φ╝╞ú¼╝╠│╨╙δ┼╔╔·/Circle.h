#include<iostream>
using namespace std;
const  int  pi=3.14159;
class Circle:public Shape
{
private:
	int r;
public:
	int getr(){ return r; }
	void setr(int R){ r=R; }
	int getArea(){ return pi*r*r;}
	Circle(int R,int ID):r(R),Shape(ID){ }
	~Circle();
};
