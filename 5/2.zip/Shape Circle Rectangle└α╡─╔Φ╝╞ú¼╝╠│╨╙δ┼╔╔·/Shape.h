#include<iostream>
using namespace std;
class Shape
{
private:
	int m_ID;
public:
	int getID(){ return m_ID; }
	void setID(int ID){ m_ID=ID; }
	int getArea(){ return 0; }
	Shape(int ID):m_ID(ID){ }
	~Shape();	
};
