#include<iostream>
using namespace std;
class Rectangle:public Shape
{
private:
	int h,w;
public:
	int geth(){ return h; }
	int getw(){ return w; }
	void seth(int H){ h=H; }
	void setw(int W){ w=W; }
	int getArea(){ return h*w; }
	Rectangle(int H,int W,int ID):h(H),w(W),Shape(ID){ }
	~Rectangle();
};

