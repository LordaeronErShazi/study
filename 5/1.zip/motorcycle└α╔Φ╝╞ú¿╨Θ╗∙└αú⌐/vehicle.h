#include<iostream>
using namespace std;
class vehicle
{
private:
	int maxspeed,weight;
public:
	void run(){ cout<<"vehicle run"<<ednl; }
	void stop(){ cout<<"vehicle stop"<<ednl; }
	vehicle(int maxspeed,int weight):this->maxspped(maxspeed),this->weight(weight)
	{
		cout<<"vehicle constructor called. maxspeed:"<<maxspeed<<"; weight"<<weight<<endl; 
	}
	~vehicle()
	{
		cout<<"vehicle destructor called. maxspeed:"<<maxspeed<<"; weight"<<weight<<endl; 
	}
};
