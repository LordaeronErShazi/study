#include <iostream>
using namespace std;
class vehicle
{
private:
	int maxspeed,weight;
public:
	void run(){ cout<<"vehicle run"<<endl; }
	void stop(){ cout<<"vehicle stop"<<endl; }
	vehicle(int speed,int weig):maxspeed(speed),weight(weig)
	{
		cout<<"vehicle constructor called. maxspeed:"<<maxspeed<<"; weight"<<weight<<endl; 
	}
	~vehicle()
	{
		cout<<"vehicle destructor called. maxspeed:"<<maxspeed<<"; weight"<<weight<<endl; 
	}
};
class bicycle: virtual public vehicle
{
private:
	int height;
public://���� 
	bicycle(int heig,int speed,int weig):height(heig),vehicle(speed,weig)
	{
		cout<<"bicycle constructor called. height:"<<height<<endl;
	}
	~bicycle()
	{
		cout<<"bicycle destructor called. height:"<<height<<endl;
	}
};
class motorcar: virtual public vehicle
{
private:
	int seatnum;
public://���� 
	motorcar(int num,int speed,int weig):seatnum(num),vehicle(speed,weig)
	{
		cout<<"motorcar constructor called. setnum:"<<seatnum<<endl;
	}
	~motorcar()
	{
		cout<<"motorcar destructor called. setnum:"<<seatnum<<endl;
	}
};
class motorcycle: public bicycle,public motorcar
{
public://���� 
	motorcycle(int heig,int num,int speed,int weig):bicycle(heig,speed,weig),motorcar(num,speed,weig),vehicle(speed,weig)
	{
		cout<<"motorcycle constructor called"<<endl;
	}
	~motorcycle()
	{
		cout<<"motorcycle destructor called"<<endl;
	}
};
int  main(int  argc,  char  *argv[])
{
	motorcycle  m(1,  2,  3,  4);//1��ʾheight��2��ʾsetnum��3��ʾmaxspeed��4��ʾweight
    m.run();
	m.stop();
    return  0;
}
