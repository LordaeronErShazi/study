#include<iostream>
using namespace std;
class motorcycle: public bicycle,public motorcar
{
public://���� 
	motorcycle(int height,int setnum,int maxspeed,int weight):bicycle(height),motorcar(seatnum),vehicle(maxspeed,weight)
	{
		cout<<"motorcycle constructor called"<<endl;
	}
	~motorcycle()
	{
		cout<<"motorcycle destructor called"<<endl;
	}
};
