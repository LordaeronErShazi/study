#include<iostream>
using namespace std;
class motorcar: virtual public vehicle
{
private:
	int seatnum;
public://���� 
	motorcar(int seatnum):this->seatnum(seatnum)
	{
		cout<<"motorcar constructor called. setnum:"<<seatnum<<endl;
	}
	~motorcar()
	{
		cout<<"motorcar destructor called. setnum:"<<seatnum<<endl;
	}
};
