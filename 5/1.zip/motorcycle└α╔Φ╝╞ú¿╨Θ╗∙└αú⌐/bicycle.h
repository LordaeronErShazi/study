#include<iostream>
using namespace std;
class bicycle: virtual public vehicle
{
private:
	int height;
public://���� 
	bicycle(int height):this->height(height)
	{
		cout<<"bicycle constructor called. height:"<<height<<endl;
	}
	~bicycle()
	{
		cout<<"bicycle destructor called. height:"<<height<<endl;
	}
};
